echo
echo

cd ./0
python3 3b-testing.py
python3 3c-testing.py
cd ..
echo
echo

