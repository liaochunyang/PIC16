from scrapy.spiders import Spider
from scrapy.http import Request
from scrapy.linkextractors import LinkExtractor
from filedownload.items import FiledownloadItem
import random

class WikipediaImageSpider(Spider):
     
    name = "image-spider"
    
    # only allowed to crawl here
    allowed_domains = [
        "en.wikipedia.org"
        ]
    
    # start with penguins
    start_urls = [
        "https://en.wikipedia.org/wiki/Penguin"
    ]

    # don't go to any pages with these patterns
    deny_urls = [
        "https://en\.wikipedia\.org/wiki/Wikipedia.*",
        "https://en\.wikipedia\.org/wiki/Main_Page",
        "https://en\.wikipedia\.org/wiki/Free_Content",
        "https://en\.wikipedia\.org/wiki/Talk.*",
        "https://en\.wikipedia\.org/wiki/Portal.*",
        "https://en\.wikipedia\.org/wiki/Special.*",
        "https://en\.wikipedia\.org/wiki/File.*",
        ".*#.*",
        ".*Help:.*",
        ".*Category:.*",
        ".*(identifier).*",
        ".*Template:.*",
        ".*Dictionary.*",
        ".*language.*",
        ".*disambiguation.*"
    ]
    
    # this is a handy gadget that will get all the links on a page
    # for us, except the ones that are denied above. Stored as a 
    # class variable of our spider. 
    link_extractor = LinkExtractor(allow="https://en\.wikipedia\.org/wiki/.+", deny=deny_urls)
    
    
    # only download files with these extensions
    #valid_extensions = [".jpg", ".svg"]

      
    def parse(self, response):
        
        # find out thumbnail elements, and get the link to the image pages
        image_boxes = response.css("figure")
        image_links = image_boxes.css("a.mw-file-description")
        if image_links:
            image_suffixes = [link.attrib["href"] for link in image_links]
            prefix = "https://en.wikipedia.org"
            image_urls = [prefix + suffix for suffix in image_suffixes]

            # visit the pages with images and when you get there, do this method
            # called parse_image_page, which will download the files
            for url in image_urls:    
                yield Request(url, callback = self.parse_image_page)
            
            # visit the first 10 links and repeat
            links = self.link_extractor.extract_links(response)    
            for link in links[:10]:
                 yield Request(link.url, callback = self.parse)
            # yield Request(random.choices(links)[0].url, callback = self.parse)
            #yield Request(links[0].url, callback = self.parse)
    
    def parse_image_page(self, response):
        # get the links to the actual image files
        link_resolutions = [r.attrib["href"] for r in response.css("a.mw-thumbnail-link").css("a")]
        
        # if there are links
        if link_resolutions:
            
            # pick the lowest resolution (smallest file size)
            res = min(len(link_resolutions), 1)
            url = link_resolutions[res]
            
            # for unknown reasons, sometimes the https: prefix gets chopped
            # off, so we need to add it back on
            if "https:" not in url:
                url = "https:" + url
            
            # download the file
            item = FiledownloadItem() # we defined it in items.py
            item['file_urls'] = [url] # give the urls to the files
            # scrapy knows to set item['files'] with the image files we're interested in
            # once we yield it
            yield item

    def parse_start_url(self, response):
        """
        It's necessary to implement this method in order to 
        ensure that the very first page will have its data 
        recorded. 
        """
        return self.parse(response)

