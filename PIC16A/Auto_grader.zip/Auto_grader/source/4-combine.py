import json

with open('config.json', 'r') as f:
  config = json.load(f)

combined_results = { 'visibility': 'visible', 'stdout_visibility': 'visible', 'tests': [] }

for i in range(len(config['configurations'])):
  with open(str(i) + '/results.json', 'r') as f:
    individual_result = json.load(f)
    combined_results['tests'].extend(individual_result['tests'])

with open('../results/results.json', 'w') as f:
  json.dump(combined_results, f, indent = 2)