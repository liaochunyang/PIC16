import json
import os




with open('config.json', 'r') as f:
  config = json.load(f)




results = []




try:
  with open('output.txt', 'r') as f:
    output = f.read()
except:
  output = 'There was a runtime error that was fatal for the autograding process.'

# we show a student the output produced by the testing script...
print(output)




source_of_output     = config['source_of_output']
whitespace_sensitive = config['whitespace_sensitive']
case_sensitive       = config['case_sensitive']
found_not_matched    = config['found_not_matched']
invariant_output     = config['invariant_output']
varying_output       = config['varying_output']
scores               = config['scores']
comments             = config['comments']




invariant_output_og = invariant_output.copy()

if not whitespace_sensitive:
  output = output.replace(' ', '')
  output = output.replace('\n', '')
  output = output.replace('\t', '')

  for i in range(len(invariant_output)):
    invariant_output[i] = invariant_output[i].replace(' ', '')
    invariant_output[i] = invariant_output[i].replace('\n', '')
    invariant_output[i] = invariant_output[i].replace('\t', '')

  for i in range(len(varying_output)):
    for j in range(len(varying_output[i])):
      varying_output[i][j] = varying_output[i][j].replace(' ', '')
      varying_output[i][j] = varying_output[i][j].replace('\n', '')
      varying_output[i][j] = varying_output[i][j].replace('\t', '')

if not case_sensitive:
  output = output.casefold()

  for i in range(len(invariant_output)):
    invariant_output[i] = invariant_output[i].casefold()

  for i in range(len(varying_output)):
    for j in range(len(varying_output[i])):
      varying_output[i][j] = varying_output[i][j].casefold()




# the grading script works by finding invariant_output
# and looking in between for varying_output...




# we record the positions of invariant_output...

idx = 0
indices = []

for i in range(len(invariant_output)):
  indices.append(output.find(invariant_output[i], idx))

  if indices[i] != -1:
    idx = indices[i] + len(invariant_output[i])

idx = len(indices)
indices.append(len(output))

while idx > 0:
  if indices[idx - 1] == -1:
    indices[idx - 1] = indices[idx]

  idx -= 1




for i in range(len(invariant_output)):
  result = { 'score': None,
             'max_score': max(scores[i], default = 0),
             'output': None }




  # suitable comments are created when invariant_output is not found...

  if indices[i] == indices[i + 1]:
    result['score'] = 0

    if source_of_output == 'student':
      result['output'] = f'Output did not contain the text "{ invariant_output_og[i] }".'
    elif source_of_output == 'script':
      result['output'] = f'Script did not reach the test case starting with "{ invariant_output_og[i] }".'
    else:
      result['output'] = ''




  # when the corresponding element of varying_output is non-empty,
  # we seek out each varying_output one-by-one...

  elif len(varying_output[i]) != 0:
    idx = indices[i] + len(invariant_output[i])
    j = 0

    while j < len(varying_output[i]):
      match = varying_output[i][j] == output[idx : indices[i + 1]]
      found = output.find(varying_output[i][j], idx, indices[i + 1])

      # we can choose to be less strict than looking for an exact match
      # and respond to whether we find the varying_output or not...

      if match or (found_not_matched and found != -1):
        break

      j += 1


    # we use either the specified scores and comments or say
    # "Incorrect" when a suitable commment is not provided...

    if j == len(varying_output[i]):
      result['score'] = 0

      if j < len(comments[i]):
        result['output'] = comments[i][j]
      else:
        result['output'] = 'Incorrect.'            

    else:
      result['score']  = scores[i][j]
      result['output'] = comments[i][j]




  if result['score'] is not None and result['output'] is not None:
    results.append(result)




with open('results.json', 'w') as f:
  json.dump({ 'tests' : results }, f, indent = 2)