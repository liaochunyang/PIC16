import scrapy

'''
1. from terminal, run:
scrapy startproject tutorial
to create the framework.

2. inside tutorial > tutorial > spiders folder,
make this quotes_spider.py file 
'''

class QuotesSpider1(scrapy.Spider):
    name = "quotes1" # each spider class needs unique name

    # needs urls to start scraping/crawling from
    start_urls =["https://quotes.toscrape.com/page/1/",
    "https://quotes.toscrape.com/page/2/"]

    # needs a parse method to know what to do with the response object
    # this response object is the same one that we saw on 
    # terminal
    def parse(self, response):
        page_num = response.url.split("/")[-2]
        filename = f'quotes-{page_num}.html'
        with open(filename, 'wb') as f:
            f.write(response.body)
