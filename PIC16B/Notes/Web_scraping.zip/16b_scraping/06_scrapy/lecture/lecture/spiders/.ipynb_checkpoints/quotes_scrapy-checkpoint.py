import scrapy

'''
1. from terminal, run:
scrapy startproject tutorial
to create the framework.

2. inside tutorial > tutorial > spiders folder,
make this quotes_spider.py file 
'''

class QuotesSpider1(scrapy.Spider):
    name = "quotes1" # each spider class needs unique name

    # needs urls to start scraping/crawling from
    start_urls =["https://quotes.toscrape.com/page/1/",
    "https://quotes.toscrape.com/page/2/"]

    # needs a parse method to know what to do with the response object
    # this response object is the same one that we saw on 
    # terminal
    def parse(self, response):
        page_num = response.url.split("/")[-2]
        filename = f'quotes-{page_num}.html'
        with open(filename, 'wb') as f:
            f.write(response.body)

class QuotesSpider2(scrapy.Spider):
    name = "quotes2" # each spider class needs unique name

    # needs urls to start scraping/crawling from
    start_urls =["https://quotes.toscrape.com/page/1/",
    "https://quotes.toscrape.com/page/2/"]

    def parse(self, response):
        #loop through an iterable of quotes
        for quote in response.css("div.quote"):
            #extract the text of the quote
            text = quote.css("span.text::text").get()
            
            # author and tags
            author = quote.css("small.author::text").get()
            tags = quote.css("div.tags a.tag::text").getall()
            tags = ",".join(tags)
            
            yield {
                "text": text,
                "author": author, 
                "tags": tags,
            }

class QuotesSpider3(scrapy.Spider):
    name = "quotes3"
    
    start_urls = [
        "http://quotes.toscrape.com/page/1/"
    ]
    
    def parse(self, response):
        
        # first part of this method is same as before
        for quote in response.css("div.quote"):
            text = quote.css("span.text::text").get()
            author = quote.css("small.author::text").get()
            tags = quote.css("div.tags a.tag::text").getall()
            tags = ",".join(tags)
            
            yield {
                "text" : text,
                "author": author,
                "tags": tags
            }

        # NEW PART HERE
        # now we need to add logic for *following links*. 
        # After yielding the data (above), we also need to 
        # construct and yield a *Request* object with the 
        # appropriate URL, and then specifying what should 
        # happen when we get there as a *callback*
        
        # find the link to the next page (it's the "next" button)
        # the href is the part of the HTML element that actually 
        # contains the hyperlink. 

        # next_page = response.css("li.next a").attrib["href"] # not safe, as attrib dict could be empty
        next_page = response.css('li.next a::attr(href)').get()
        if next_page: # same as if next_page is not None:
            # next_page = response.urljoin(next_page)
            # yield scrapy.Request(next_page, callback = self.parse)
            # same as: 
            yield response.follow(next_page, callback=self.parse)