import scrapy
from scrapy.linkextractors import LinkExtractor

# make sure to add CLOSESPIDER_PAGECOUNT = 5 in settings.py so that
# you're not crawling wikipedia forever.

class WikipediaSpider(scrapy.Spider):
    name = "wiki"
    # only allowed to crawl here
    allowed_domains = [
        "en.wikipedia.org"
        ]
    
    start_urls = [
        "https://en.wikipedia.org/wiki/Penguin"
    ]
    
    deny_urls = [
        "https://en\.wikipedia\.org/wiki/Wikipedia.*",
        "https://en\.wikipedia\.org/wiki/Main_Page",
        "https://en\.wikipedia\.org/wiki/Free_Content",
        "https://en\.wikipedia\.org/wiki/Talk.*",
        "https://en\.wikipedia\.org/wiki/Portal.*",
        "https://en\.wikipedia\.org/wiki/Special.*",
        "https://en\.wikipedia\.org/wiki/File.*",
        ".*#.*",
        ".*Help:.*",
        ".*Category:.*",
        ".*(identifier).*",
        ".*Template:.*",
        ".*Dictionary.*",
        ".*language.*",
        ".*disambiguation.*"
    ]
    
    
    link_extractor = LinkExtractor(
        allow="https://en\.wikipedia\.org/wiki/.+",
        deny=deny_urls)
    
    def parse(self, response):
        # topic of the current page
        current = response.url.split("/")[-1]
        # get all the href links from this page
        links = self.link_extractor.extract_links(response)
        
        for link in links:
            # record information of what page links to what
            yield {
                "source": current,
                "target": link.url.split("/")[-1]
            }
            # ask scrapy to visit the new link 
            # once it get sthrer, call self.parse recursively
            yield scrapy.Request(link.url, callback=self.parse)
            
    def parse_start_url(self, response):
        # make sure that the information of the first page is recorded
        return self.parse(response)
    
# from terminal, run:
# scrapy crawl wiki -o links.csv