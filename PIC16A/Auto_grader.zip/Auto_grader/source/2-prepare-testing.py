import json
import shutil


with open('config.json', 'r') as f:
  config = json.load(f)


# 3a-testing.sh simply executes
# 3b-testing.py and 3c-testing.py
# for each of the configurations

with open('3a-testing.sh', 'w') as f:
  print('echo', file = f)
  print('echo', file = f)
  print('',     file = f)

  for i in range(len(config['configurations'])):
    print('cd ./' + str(i),        file = f)
    print('python3 3b-testing.py', file = f)
    print('python3 3c-testing.py', file = f)
    print('cd ..',                 file = f)
    print('echo',                  file = f)
    print('echo',                  file = f)
    print('',                      file = f)


# lots of the configuration settings have useful default values;
# the code below is the simplest place to see them listed...

for i, configuration in enumerate(config['configurations']):
  try:
    main_file = configuration['main_file']
  except:
    if                                         len(configuration['testing_files']) == 1: main_file = configuration['testing_files'][0]
    elif len(configuration['student_files']) + len(configuration['testing_files']) == 1: main_file = configuration['student_files'][0]
    else:                                                                                main_file = None;  print('No main file specified')

  try:
    source_of_output = configuration['source_of_output']
  except:
    if len(configuration['testing_files']) == 0: source_of_output = 'student'
    else:                                        source_of_output = 'script'

  try:
    whitespace_sensitive = configuration['whitespace_sensitive']
  except:
    whitespace_sensitive = False

  try:
    case_sensitive = configuration['case_sensitive']
  except:
    case_sensitive = False

  try:
    found_not_matched = configuration['found_not_matched']
  except:
    found_not_matched = False

  try:
    execution_time = configuration['execution_time']
  except:
    execution_time = 10

  invariant_output = configuration['invariant_output']
  varying_output   = configuration['varying_output']
  scores           = configuration['scores']
  comments         = configuration['comments']


  # the code below is the simplest way to see the rules that govern
  # invariant_output, varying_output, scores, and comments:

  # - invariant_output should be a list
  # - varying_output, scores, and comments should be lists of lists
  # - invariant_output and varying_output should have the same length
  # - for every non-empty element of varying_output, scores should have an element of the same length
  # - scores and comments should have the same length
  # - elements of comments should either have the same length as the corresponding elements of scores
  #   or they should have exactly one more comment to provide information on an incorrect output
  # - invariant_outputs should not appear within varying_outputs


  for j in range(len(varying_output)):
    if len(varying_output[j]) == 0:
      scores.insert(j, [])
      comments.insert(j, [])


  if len(invariant_output) != len(varying_output):
    print(f'MAJOR ISSUE: The length of invariant_output and varying_output differs for configuration {i} (0-indexed)')

  if len(varying_output) != len(scores):
    print(f'MAJOR ISSUE: varying_output and scores are incompatible for configuration {i} (0-indexed)')

  if len(scores) != len(comments):
    print(f'MAJOR ISSUE: The length of scores and comments differs for configuration {i} (0-indexed)')

  for j in range(len(varying_output)):
    if len(varying_output[j]) != len(scores[j]):
      print(f'MAJOR ISSUE: varying_output and scores are incompatible for configuration {i} (0-indexed)')

  for j in range(len(scores)):
    if len(scores[j]) != len(comments[j]) and len(scores[j]) + 1 != len(comments[j]):
      print(f'MAJOR ISSUE: scores and comments are incompatible for configuration {i} (0-indexed)')


  for a in invariant_output:
    for b in varying_output:
      for c in b:
        if type(c) is str:
          _a = a
          _c = c

          if not whitespace_sensitive:
            _a = a.replace(' ', '').replace('\n', '').replace('\t', '')
            _c = c.replace(' ', '').replace('\n', '').replace('\t', '')

          if not case_sensitive:
            _a = a.casefold()
            _c = c.casefold()

          if _a in _c:
            print(f'MAJOR ISSUE: For configuration {i} (0-indexed) an invariant_output "{a}" appears')
            print(f'in a varying_output "{c}" after accounting for whitespace and case sensitivity')


  configuration_config = { 'main_file'            : main_file,
                           'source_of_output'     : source_of_output,
                           'whitespace_sensitive' : whitespace_sensitive,
                           'case_sensitive'       : case_sensitive,
                           'found_not_matched'    : found_not_matched,
                           'execution_time'       : execution_time,
                           'invariant_output'     : invariant_output,
                           'varying_output'       : varying_output,
                           'scores'               : scores,
                           'comments'             : comments }


  idx = str(i)

  with open(idx + '/config.json', 'w') as f:
    json.dump(configuration_config, f, indent = 2)

  shutil.copy('3b-testing.py', idx + '/')
  shutil.copy('3c-testing.py', idx + '/')