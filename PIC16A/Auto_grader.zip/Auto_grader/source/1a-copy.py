import json
import os
import shutil


with open('config.json', 'r') as f:
  config = json.load(f)


for i in range(len(config['configurations'])):
  os.mkdir(str(i))


for i, configuration in enumerate(config['configurations']):
  student_files = configuration['student_files']
  testing_files = configuration['testing_files']

  try:
    user_input = configuration['user_input']
  except:
    user_input = ''


  idx = str(i)

  for student_file in student_files:
    try:
      shutil.copy('../submission/' + student_file, idx + '/')
    except:
      print(student_file + ' was not submitted')

  for testing_file in testing_files:
    shutil.copy('./scripts/' + testing_file, idx + '/')

  with open(idx + '/input.txt', 'w') as f:
    print(user_input, file = f)