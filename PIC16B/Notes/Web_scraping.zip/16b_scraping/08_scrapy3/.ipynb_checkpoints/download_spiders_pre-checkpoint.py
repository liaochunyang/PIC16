from scrapy.spiders import Spider
from scrapy.http import Request
from scrapy.linkextractors import LinkExtractor
from filedownload.items import FileDownloadItem
import random

class WikipediaImageSpider(Spider):
     
    name = "image-spider"
    
    # only allowed to crawl here
    allowed_domains = [
        "en.wikipedia.org"
        ]
    
    # start with penguins
    start_urls = [
        "https://en.wikipedia.org/wiki/Penguin"
    ]

    # don't go to any pages with these patterns
    deny_urls = [
        "https://en\.wikipedia\.org/wiki/Wikipedia.*",
        "https://en\.wikipedia\.org/wiki/Main_Page",
        "https://en\.wikipedia\.org/wiki/Free_Content",
        "https://en\.wikipedia\.org/wiki/Talk.*",
        "https://en\.wikipedia\.org/wiki/Portal.*",
        "https://en\.wikipedia\.org/wiki/Special.*",
        "https://en\.wikipedia\.org/wiki/File.*",
        ".*#.*",
        ".*Help:.*",
        ".*Category:.*",
        ".*(identifier).*",
        ".*Template:.*",
        ".*Dictionary.*",
        ".*language.*",
        ".*disambiguation.*"
    ]
    
    # this is a handy gadget that will get all the links on a page
    # for us, except the ones that are denied above. Stored as a 
    # class variable of our spider. 
    link_extractor = LinkExtractor(allow="https://en\.wikipedia\.org/wiki/.+", deny=deny_urls)
    
    
    # only download files with these extensions
    valid_extensions = [".jpg", ".svg"]

      
    def parse(self, response):
        pass 
    
    def parse_start_url(self, response):
        """
        It's necessary to implement this method in order to 
        ensure that the very first page will have its data 
        recorded. 
        """
        return self.parse(response)

