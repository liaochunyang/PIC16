def compare_val_w_idx(L):
    M = []
    for idx, val in enumerate(L):
        if   val > idx: 
            M.append( 1)
        elif val < idx: 
            M.append(-1)
        else: 
            M.append(0)

    return M 