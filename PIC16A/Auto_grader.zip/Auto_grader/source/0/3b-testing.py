import json
import os
import subprocess




with open('config.json', 'r') as f:
  config = json.load(f)




if os.path.exists('./sol'):
  output = subprocess.run(f"cat ./sol/input.txt | python3 ./sol/{ config['main_file'] }", capture_output = True, shell = True, text = True, timeout = config['execution_time'])
  output = output.stdout


  invariant_output = config['invariant_output']
  varying_output   = config['varying_output']


  # this checks that the invariant_outputs appear in a provided solution;
  # this check is whitespace sensitive and case sensitive

  idx = 0
  indices = []

  for i in range(len(invariant_output)):
    indices.append(output.find(invariant_output[i], idx))

    if indices[i] == -1:
      print(f'MAJOR ISSUE: An invariant_output "{ invariant_output[i] }" was not found in the solution provided')
    else:
      idx = indices[i] + len(invariant_output[i])

  indices.append(len(output))


  # this replaces non-string values in varying_output
  # with the output produced by a provided solution

  output_sol = [output[indices[i] + len(invariant_output[i]) : indices[i + 1]] for i in range(len(invariant_output))]

  for i in range(len(varying_output)):
    for j in range(len(varying_output[i])):
      if type(varying_output[i][j]) is not str:
        varying_output[i][j] = output_sol[i]

  with open('config.json', 'w') as f:
    json.dump(config, f, indent = 2)




# this is separated off from 3c-testing.py
# so that output.txt not existing
# indicates an issue has occurred

try:
  output = subprocess.run(f"cat input.txt | python3 { config['main_file'] }", capture_output = True, shell = True, text = True, timeout = config['execution_time'])
  output = output.stdout
except:
  output = f"Code execution exceeded { config['execution_time'] } seconds."


with open('output.txt', 'w') as f:
  print(output, file = f, end = '')