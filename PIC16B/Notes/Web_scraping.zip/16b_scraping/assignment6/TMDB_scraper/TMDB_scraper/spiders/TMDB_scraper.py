#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 24 02:05:54 2025

@author: liaochunyang
"""


import scrapy

class TmdbSpider(scrapy.Spider):
    name = 'tmdb_spider'
    def __init__(self, subdir=None, *args, **kwargs):
        self.start_urls = [f"https://www.themoviedb.org/movie/{subdir}/"]
        
    def parse(self,response):
        url = response.url + 'cast'
        yield scrapy.Request(url, callback=self.parse_full_credits)
        
    def parse_full_credits(self, response):
        """Yields requests for each actor's page on the Full Cast & Crew page."""
        actor_links = [r.attrib["href"] for r in  response.css('li.card').css("a")]
 
        for links in actor_links:
            yield scrapy.Request("https://www.themoviedb.org" + links, callback=self.parse_actor_page)

    def parse_actor_page(self, response):
        
        actor_name = response.url.split('/')[-1:]
        
        for movie in response.css("table.credit_group").css('a.tooltip'):
            
            movie_name = movie.css("::text").get()
        
            yield {"actor" : actor_name, "movie_or_TV_name" : movie_name}
        