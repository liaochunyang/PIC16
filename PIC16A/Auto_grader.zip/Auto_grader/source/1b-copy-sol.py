import json
import os
import shutil


with open('config.json', 'r') as f:
  config = json.load(f)


if os.path.exists('./solutions'):
  for i in range(len(config['configurations'])):
    os.mkdir(str(i) + '/sol')


  for i, configuration in enumerate(config['configurations']):
    student_files = configuration['student_files']
    testing_files = configuration['testing_files']

    try:
      user_input = configuration['user_input']
    except:
      user_input = ''


    idx = str(i) + '/sol'

    for student_file in student_files:
      shutil.copy('./solutions/' + student_file, idx + '/')

    for testing_file in testing_files:
      shutil.copy('./scripts/' + testing_file, idx + '/')

    with open(idx + '/input.txt', 'w') as f:
      print(user_input, file = f)