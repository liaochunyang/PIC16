import ex_105 as student

print("Test Example 1: ", student.compare_val_w_idx([4,5,6,3,4,5,2,3,4]))
